fx_version 'cerulean'
game 'gta5'

author 'R.Robertson - Echo Kilo Studios'
description 'Custom /me, /gme, and /ooc commands script - Dev Log for version 1.2.0'
version '1.2.0'

server_scripts {
    'config.lua',
    'commands.lua'
}
