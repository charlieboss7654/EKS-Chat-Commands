-- Load config
if Config == nil then
    Config = {}
end

local userNames = {}
local chatCooldowns = {}

-- Add chat suggestions for all commands on resource start
AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end

    TriggerClientEvent('chat:addSuggestion', -1, '/user', 'Change your display username in chat', {
        { name = 'new username', help = 'The username to display in chat' }
    })
    TriggerClientEvent('chat:addSuggestion', -1, '/me', 'Describe an action in your area', {
        { name = 'action', help = 'What your character is doing' }
    })
    TriggerClientEvent('chat:addSuggestion', -1, '/gme', 'Describe a global action', {
        { name = 'action', help = 'What your character is doing (global)' }
    })
    TriggerClientEvent('chat:addSuggestion', -1, '/do', 'Describe a scene or environment', {
        { name = 'description', help = 'Describe what others would see or experience' }
    })
    TriggerClientEvent('chat:addSuggestion', -1, '/ooc', 'Out of character message', {
        { name = 'message', help = 'Your OOC chat message' }
    })
    TriggerClientEvent('chat:addSuggestion', -1, '/tweet', 'Send a tweet as a username', {
        { name = 'username', help = 'The display username (Twitter handle)' },
        { name = 'message', help = 'Tweet content' }
    })
    TriggerClientEvent('chat:addSuggestion', -1, '/ad', 'Send an advertisement as a username', {
        { name = 'username', help = 'The display username for the ad' },
        { name = 'message', help = 'The advertisement content' }
    })
    TriggerClientEvent('chat:addSuggestion', -1, '/darkweb', 'Post an anonymous dark web message', {
        { name = 'message', help = 'Dark web message content' }
    })
    TriggerClientEvent('chat:addSuggestion', -1, '/cctv', 'Describe what CCTV sees', {
        { name = 'message', help = 'What the CCTV camera is recording' }
    })
    TriggerClientEvent('chat:addSuggestion', -1, '/trafficam', 'Describe what the traffic cam sees', {
        { name = 'message', help = 'What the traffic cam is recording' }
    })
end)

RegisterCommand('user', function(source, args)
    if #args < 1 then
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"System", "Usage: /user <new_username>"}
        })
        return
    end
    local newName = table.concat(args, " ")
    userNames[source] = newName
    TriggerClientEvent('chat:addMessage', source, {
        color = {0, 255, 0},
        args = {"System", "Your username is now: " .. newName}
    })
end)

local function getDisplayName(source)
    return userNames[source] or GetPlayerName(source)
end

RegisterCommand('me', function(source, args)
    local text = table.concat(args, " ")
    local displayName = getDisplayName(source)
    if text and text ~= "" then
        SendRadialMessage(source, string.format("[Me] %s", displayName), {255, 182, 193}, text, {255, 255, 255})
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {"[Error]", "Usage: /me [action]"}
        })
    end
end)

RegisterCommand('gme', function(source, args)
    local text = table.concat(args, " ")
    local displayName = getDisplayName(source)
    if text and text ~= "" then
        TriggerClientEvent('chat:addMessage', -1, {
            color = {255, 182, 193},
            args = {"[GME] " .. displayName, "^7" .. text}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {"[Error]", "Usage: /gme [global action]"}
        })
    end
end)

RegisterCommand('do', function(source, args)
    local text = table.concat(args, " ")
    local displayName = getDisplayName(source)
    if text and text ~= "" then
        TriggerClientEvent('chat:addMessage', -1, {
            color = {255, 255, 0},
            args = {"[Do] " .. displayName, "^7" .. text}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {"[Error]", "Usage: /do [description]"}
        })
    end
end)

RegisterCommand('ooc', function(source, args)
    local text = table.concat(args, " ")
    local displayName = getDisplayName(source)
    if text and text ~= "" then
        TriggerClientEvent('chat:addMessage', -1, {
            color = {173, 216, 230},
            args = {"[OOC] " .. displayName, "^7" .. text}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {"[Error]", "Usage: /ooc [message]"}
        })
    end
end)

RegisterCommand('tweet', function(source, args)
    if #args < 2 then
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {"[Error]", "Usage: /tweet [username] [message]"}
        })
        return
    end
    local username = args[1]
    table.remove(args, 1)
    local text = table.concat(args, " ")
    TriggerClientEvent('chat:addMessage', -1, {
        color = {0, 255, 255},
        args = {"[Tweet] @" .. username, "^7" .. text}
    })
end)

RegisterCommand('ad', function(source, args)
    if #args < 2 then
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {"[Error]", "Usage: /ad [username] [advertisement message]"}
        })
        return
    end
    local username = args[1]
    table.remove(args, 1)
    local text = table.concat(args, " ")
    TriggerClientEvent('chat:addMessage', -1, {
        color = {255, 140, 0},
        args = {"[Ad] " .. username, "^7" .. text}
    })
end)

RegisterCommand('darkweb', function(source, args)
    local text = table.concat(args, " ")
    if text and text ~= "" then
        TriggerClientEvent('chat:addMessage', -1, {
            color = {64, 64, 64},
            args = {"[Dark Web]", "^7" .. text}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {"[Error]", "Usage: /darkweb [message]"}
        })
    end
end)

RegisterCommand('cctv', function(source, args)
    local text = table.concat(args, " ")
    if text and text ~= "" then
        TriggerClientEvent('chat:addMessage', -1, {
            color = {255, 255, 0},
            args = {"[CCTV]", "^7" .. text}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {"[Error]", "Usage: /cctv [location] [what you see/are looking for]"}
        })
    end
end)

RegisterCommand('trafficam', function(source, args)
    local text = table.concat(args, " ")
    if text and text ~= "" then
        TriggerClientEvent('chat:addMessage', -1, {
            color = {255, 255, 0},
            args = {"[Traffic Cam]", "^7" .. text}
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {"[Error]", "Usage: /trafficam [message]"}
        })
    end
end)

function SendRadialMessage(source, prefix, prefixColor, text, textColor)
    local players = GetPlayers()
    local sourceCoords = GetEntityCoords(GetPlayerPed(source))
    for _, playerId in ipairs(players) do
        local targetCoords = GetEntityCoords(GetPlayerPed(playerId))
        local distance = #(sourceCoords - targetCoords)
        if distance <= 20.0 then
            TriggerClientEvent('chat:addMessage', playerId, {
                args = {prefix, "^7" .. text},
                color = prefixColor
            })
        end
    end
end

-- SINGLE chatMessage handler: does slowmode and custom name
AddEventHandler('chatMessage', function(source, name, msg)
    -- Only apply to normal messages, not commands
    if msg:sub(1, 1) == '/' then return end

    -- Chat slowmode / cooldown logic
    if Config.ChatSlowmodeEnabled then
        local now = os.time()
        if chatCooldowns[source] and now - chatCooldowns[source] < (Config.ChatSlowmodeSeconds or 5) then
            TriggerClientEvent('chat:addMessage', source, {
                color = {255, 0, 0},
                multiline = false,
                args = {"[Chat Watch]", Config.ChatSlowmodeMessage or "Repetitive chat is disabled."}
            })
            CancelEvent()
            return
        else
            chatCooldowns[source] = now
        end
    end

    -- Use custom display name logic
    local displayName = getDisplayName(source)
    TriggerClientEvent('chat:addMessage', -1, {
        color = {255,255,255},
        multiline = true,
        args = { displayName, msg }
    })
    CancelEvent()
end)

AddEventHandler('playerDropped', function(reason)
    userNames[source] = nil
    chatCooldowns[source] = nil
end)
