-- config.lua
Config = {}

Config.ChatSlowmodeEnabled = true -- Set to false to disable chat cooldown
Config.ChatSlowmodeSeconds = 5    -- Cooldown time in seconds
Config.ChatSlowmodeMessage = "Repetitive chat is disabled."
